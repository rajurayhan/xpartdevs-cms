<?php


return [



    'all' => 'الجميع',
    'sort_by' => 'ترتيب حسب',
    'call_help' => 'طلب المساعدة:',
    'mail_us' => 'أرسل لنا:',
    'our_address' => 'عنواننا:',
 

];