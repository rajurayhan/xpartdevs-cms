<?php


return [



    'all' => 'Todos',
    'sort_by' => 'Ordenar por',
    'call_help' => 'Pedir ajuda:',
    'mail_us' => 'Envie para nós:',
    'our_address' => 'Nosso endereço:',
 

];