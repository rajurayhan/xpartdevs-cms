<?php $__env->startSection('title'); ?> <?php echo e($blogsettings->meta_title); ?> <?php $__env->stopSection(); ?>
<?php $__env->startSection('meta'); ?> <?php echo e($blogsettings->meta_description); ?> <?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>
  
  
   <div class="breadcrumb-area">
       <h1 class="breadcrumb-title"><?php echo e($blogsettings->meta_title); ?></h1>
       <ul class="page-list">
            <li class="item-home"><a class="bread-link" href="<?php echo e(route('home')); ?>" title="Home"><?php echo e($blogsettings->breadcrumbs_anchor); ?></a></li>
            <li class="separator separator-home"></li>
            <li class="item-current"><?php echo e($blogsettings->meta_title); ?></li>
        </ul>
   </div>

   <div class="blog-page-section">
      <div class="container">
        <div class="row">
            
            <div class="col-md-8">
                
            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <article class="single-post blogloop-v2">
                   <div class="blog_custom">
                      <div class="post-thumbnail">
                         <a href="<?php echo e(URL::to('/')); ?>/post/<?php echo e($post->slug); ?>">
                            <img class="blog_post_image img-fluid lazy" width="800" height="550" src="/public/img/loading-blog.gif" data-src="<?php echo e($post->photo ? '/public/images/media/' . $post->photo->file : '/public/img/200x200.png'); ?>" alt="<?php echo e($post->title); ?>">
                          </a>
                      </div>
                      <span class="post-date"><?php echo e(date('d.M.Y', strtotime($post->created_at))); ?></span>
                      <!-- POST DETAILS -->
                      <div class="post-details">
                         <div class="post-details-holder">
                            <div class="post-author-avatar">
                               <img alt="" src="/public/img/loading-blog.gif" data-src="<?php echo e($post->user->photo ? '/public/images/media/' . $post->user->photo->file : '/public/img/200x200.png'); ?>" class="avatar img-fluid lazy" height="120" width="120">
                             </div>
                            
                            <h2 class="post-name">
                               <a title="<?php echo e($post->title); ?>" href="<?php echo e(URL::to('/')); ?>/post/<?php echo e($post->slug); ?>">
                                  <?php echo e($post->title); ?>                   
                               </a>
                            </h2>

                            <div class="post-category-comment-date">
                               <span class="post-tags"><i class="fa fa-tag"></i><?php echo e($post->category->name); ?></span>
                            </div>

                            <div class="post-excerpt">
                               <p><?php echo e($post->meta_description); ?></p>
                            </div>
                         </div>
                      </div>
                   </div>
                </article>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>




            </div> <!-- col 8 -->

            <div class="col-md-4">
                
                <div class="widget_element">
                   <?php echo $blogsettings->html_sidebar1; ?>

                </div>

                <div class="widget_element">
                   <?php echo $blogsettings->html_sidebar2; ?>

                </div>

            </div>

        </div>
      </div>
   </div>
   
 

<?php $__env->stopSection(); ?>





<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/lucilzud/laravel1.lucian.host/resources/views/blog.blade.php ENDPATH**/ ?>