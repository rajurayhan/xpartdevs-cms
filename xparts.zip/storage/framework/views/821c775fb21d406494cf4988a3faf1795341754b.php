<?php $__env->startSection('title'); ?> <?php echo e($contactsetting->meta_title); ?> <?php $__env->stopSection(); ?>
<?php $__env->startSection('meta'); ?> <?php echo e($contactsetting->meta_description); ?> <?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
  
  
   <div class="breadcrumb-area">
       <h1 class="breadcrumb-title"><?php echo e($contactsetting->meta_title); ?></h1>
       <ul class="page-list">
            <li class="item-home"><a class="bread-link" href="<?php echo e(route('home')); ?>" title="Home"><?php echo e($contactsetting->breadcrumbs_anchor); ?></a></li>
            <li class="separator separator-home"></li>
            <li class="item-current"><?php echo e($contactsetting->meta_title); ?></li>
        </ul>
   </div>


   <div class="contant-section-page">
      
      <div class="container">
        
          <div class="row">
                  
                  <div class="col-md-4">
                      <div class="contact-element-wrapper">
                        <div class="contact-element">
                          <div class="icon"> <?php echo $contactsetting->box_icon1; ?></div>
                          <div class="content">
                            <h3 class="title"><?php echo $contactsetting->box_title1; ?></h3>
                            <?php echo $contactsetting->box_html1; ?>

                          </div>
                        </div>
                      </div>
                  </div>

                  <div class="col-md-4">
                      <div class="contact-element-wrapper">
                        <div class="contact-element">
                          <div class="icon"> <?php echo $contactsetting->box_icon2; ?></div>
                          <div class="content">
                            <h3 class="title"><?php echo $contactsetting->box_title2; ?></h3>
                            <?php echo $contactsetting->box_html2; ?>

                          </div>
                        </div>
                      </div>
                  </div>


                  <div class="col-md-4">
                      <div class="contact-element-wrapper">
                        <div class="contact-element">
                          <div class="icon"> <?php echo $contactsetting->box_icon3; ?></div>
                          <div class="content">
                            <h3 class="title"><?php echo $contactsetting->box_title3; ?></h3>
                            <?php echo $contactsetting->box_html3; ?>

                          </div>
                        </div>
                      </div>
                  </div>


          </div>


      </div>

   </div>

  <div class="iframe-contact">
    <div class="container">
      <div class="row">
        
        <div class="col-md-6">
            <h3> <?php echo $contactsetting->title; ?> </h3>
            <?php echo $contactsetting->iframe_txt; ?>

        </div>

        <div class="col-md-6">

              <h3><?php echo $contactsetting->form_title; ?></h3>

              <?php if($message = Session::get('success')): ?>
                  <div class="alert alert-success alert-block">
                      <button type="button" class="close" data-dismiss="alert"><i class="fas fa-times"></i></button>    
                      <strong><?php echo e($message); ?></strong>
                  </div>
              <?php endif; ?>

              <?php echo NoCaptcha::renderJs(); ?>


              

              <form method="POST" action="<?php echo e(route('contactPost')); ?>">
                 
                 <?php echo csrf_field(); ?>
                 <div class="row">
                    <div class="col-md-6">
                        <div class="form-group <?php echo e($errors->has('name') ? 'has-error' : ''); ?>">
                            <label for="name"> <?php echo $contactsetting->form_input_name; ?> </label>
                            <input name="name" type="text" class="form-control" id="name" aria-describedby="name" placeholder=" <?php echo $contactsetting->form_input_name; ?> ">
                            <span class="text-danger"><?php echo e($errors->first('name')); ?></span>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group <?php echo e($errors->has('name') ? 'has-error' : ''); ?>">
                          <label for="email"><?php echo $contactsetting->form_input_email; ?></label>
                          <input name="email" type="email" class="form-control" id="email" aria-describedby="emailHelp"
                              placeholder="<?php echo $contactsetting->form_input_email; ?>">
                          <span class="text-danger"><?php echo e($errors->first('email')); ?></span>
                        </div>
                    </div>
                    
                </div>

                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group <?php echo e($errors->has('name') ? 'has-error' : ''); ?>">
                            <label for="phone"><?php echo $contactsetting->form_input_budget; ?></label>
                            <input name="phone" type="text" class="form-control" id="phone" aria-describedby="name" placeholder="<?php echo $contactsetting->form_input_budget; ?>">
                            <span class="text-danger"><?php echo e($errors->first('phone')); ?></span>
                        </div>
                        
                    </div>
                    <div class="col-md-6">
                        <div class="form-group <?php echo e($errors->has('name') ? 'has-error' : ''); ?>">
                          <label for="budget"><?php echo $contactsetting->form_input_phone; ?></label>
                          <input name="budget" type="text" class="form-control" id="budget" aria-describedby="emailHelp"
                              placeholder="<?php echo $contactsetting->form_input_phone; ?>">
                          <span class="text-danger"><?php echo e($errors->first('budget')); ?></span>
                        </div>
                    </div>
                </div>
                
                
                <div class="form-group <?php echo e($errors->has('name') ? 'has-error' : ''); ?>">
                    <label for="exampleInputPassword1"><?php echo $contactsetting->form_message; ?></label>
                    <textarea name="comment" class="form-control" id="exampleFormControlTextarea1" rows="3"></textarea>
                    <span class="text-danger"><?php echo e($errors->first('comment')); ?></span>
                </div>



             
                <?php echo NoCaptcha::display(); ?>


                <?php if($errors->has('g-recaptcha-response')): ?>
                  <span class="text-danger"><?php echo e($errors->first('g-recaptcha-response')); ?></span>
                <?php endif; ?>


                <button type="submit" class="btn btn-style1"><?php echo $contactsetting->button_text; ?></button>
            </form>
        
        </div>


      </div>
    </div>
  </div>

 

   <div class="clients-section">
        <div class="container">
            
            <div class="clients-slider owl-carousel">
                  <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <div class="clients-slide">
                      <a title="<?php echo e($client->company_name); ?>" target="_blank" href="<?php echo e($client->company_link); ?>"><img class="client_image owl-lazy" data-src="<?php echo e($client->photo ? '/public/images/media/' . $client->photo->file : '/public/img/200x200.png'); ?>" alt="<?php echo e($client->company_name); ?>"></a>
                  </div>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            
        </div>
    </div>




<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/lucilzud/niva.lucian.host/resources/views/contact.blade.php ENDPATH**/ ?>