<div class="js-cookie-consent cookie-consent">

    <span class="cookie-consent__message">
        <?php echo trans('cookieConsent::texts.message'); ?>

    </span>

    <button class="js-cookie-consent-agree cookie-consent__agree">
        <?php echo e(trans('cookieConsent::texts.agree')); ?>

    </button>

</div>
<?php /**PATH /home/lucilzud/laravel1.lucian.host/resources/views/vendor/cookieConsent/dialogContents.blade.php ENDPATH**/ ?>