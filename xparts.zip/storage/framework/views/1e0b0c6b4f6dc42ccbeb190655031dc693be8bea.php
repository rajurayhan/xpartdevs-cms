

<?php $__env->startSection('content'); ?>

<!-- Begin Page Content -->
<div class="container-fluid">


    <!-- Page Heading -->
    <h1 class="h3 mb-2 text-gray-800"><?php echo e(clean( trans('niva-backend.all_users') , array('Attr.EnableID' => true))); ?></h1>

    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary"><?php echo e(clean( trans('niva-backend.all_users') , array('Attr.EnableID' => true))); ?></h6>
        </div>
        <div class="card-body">
            <div class="table-responsive">


                <?php if($message = Session::get('user_success')): ?>
                    <div class="alert alert-success alert-block">
                        <button type="button" class="close" data-dismiss="alert"><i class="fas fa-times"></i></button>    
                        <strong><?php echo e($message); ?></strong>
                    </div>
                <?php endif; ?>
                <?php if($message = Session::get('user_fail')): ?>
                    <div class="alert alert-danger alert-block">
                        <button type="button" class="close" data-dismiss="alert"><i class="fas fa-times"></i></button>    
                        <strong><?php echo e($message); ?></strong>
                    </div>
                <?php endif; ?>

               

                <form action="<?php echo e(route('delete.users')); ?>" method="POST" class="form-inline">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <div class="form-group">
                    <select name="checkbox_array" id="" class="form-control">
                        <option value=""><?php echo e(clean( trans('niva-backend.delete') , array('Attr.EnableID' => true))); ?></option>
                    </select>
                </div>

                <div class="form-group">
                    <input type="submit" name="delete_all" class="btn btn-primary">
                    <input type="hidden" name="current_user" value="<?php echo e(auth()->user()->id); ?>">
                </div>



                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th><input type="checkbox" id="options"></th>
                            <th><?php echo e(clean( trans('niva-backend.name') , array('Attr.EnableID' => true))); ?></th>
                            <th><?php echo e(clean( trans('niva-backend.email') , array('Attr.EnableID' => true))); ?></th>
                            <th><?php echo e(clean( trans('niva-backend.role') , array('Attr.EnableID' => true))); ?></th>
                        </tr>
                    </thead>
                    <tfoot>
                        <tr>
                            <th><input type="checkbox" id="options1"></th>
                            <th><?php echo e(clean( trans('niva-backend.name') , array('Attr.EnableID' => true))); ?></th>
                            <th><?php echo e(clean( trans('niva-backend.email') , array('Attr.EnableID' => true))); ?></th>
                            <th><?php echo e(clean( trans('niva-backend.role') , array('Attr.EnableID' => true))); ?></th>
                        </tr>
                    </tfoot>
                    <tbody>
                        <?php if($users): ?>
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><input class="checkboxes" type="checkbox" name="checkbox_array[]" value="<?php echo e($user->id); ?>"></td>
                                    <td data-label="Name">
                                        <div class="float-left-avatar">
                                            <img width="35" height="35" src="<?php echo e($user->photo ? '/public/images/media/' . $user->photo->file : '/public/img/200x200.png'); ?>" alt="">
                                        </div>
                                        <div class="float-left-user-name">
                                            <p><?php echo e($user->name); ?></p>
                                            <a href="<?php echo e(route('users.edit', $user->id)); ?>"><?php echo e(clean( trans('niva-backend.edit') , array('Attr.EnableID' => true))); ?></a>
                                        </div>
                                    </td>
                                    <td data-label="Name and surname"><?php echo e($user->email); ?></td>
                                    <td data-label="Role"><?php echo e($user->role ? $user->role->name : ''); ?></td>
                                </tr>
                             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>


                        
                    </tbody>
                </table>

                </form>
                 <?php echo $users->render(); ?>

            </div>
        </div>
    </div>

</div>
<!-- /.container-fluid -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/lucilzud/niva.lucian.host/resources/views/users/index.blade.php ENDPATH**/ ?>