

<?php $__env->startSection('content'); ?>

<!-- Begin Page Content -->
<div class="container-fluid">


    <!-- Page Heading -->
    <h1 class="h3 mb-2 text-gray-800"><?php echo e(clean( trans('niva-backend.all_members') , array('Attr.EnableID' => true))); ?></h1>

    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary"><?php echo e(clean( trans('niva-backend.all_members') , array('Attr.EnableID' => true))); ?></h6>
        </div>
        <div class="card-body">
            <div class="table-responsive">

                <a href="<?php echo e(route('about-setting.edit')); ?>" class="btn btn-primary btn-back"><?php echo e(clean( trans('niva-backend.back_aboutpage') , array('Attr.EnableID' => true))); ?></a>
                <a href="<?php echo e(route('member.create')); ?>" class="btn btn-primary btn-back"><?php echo e(clean( trans('niva-backend.create') , array('Attr.EnableID' => true))); ?></a>

                <?php if($message = Session::get('member_success')): ?>
                    <div class="alert alert-success alert-block">
                        <button type="button" class="close" data-dismiss="alert"><i class="fas fa-times"></i></button>    
                        <strong><?php echo e($message); ?></strong>
                    </div>
                <?php endif; ?>
               

                <form action="<?php echo e(route('delete.member')); ?>" method="POST" class="form-inline">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <div class="form-group">
                    <select name="checkbox_array" id="" class="form-control">
                        <option value=""><?php echo e(clean( trans('niva-backend.delete') , array('Attr.EnableID' => true))); ?></option>
                    </select>
                </div>

                <div class="form-group">
                    <input type="submit" name="delete_all" class="btn btn-primary">
                </div>



                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th><input type="checkbox" id="options"></th>
                            <th><?php echo e(clean( trans('niva-backend.photo') , array('Attr.EnableID' => true))); ?></th>
                            <th><?php echo e(clean( trans('niva-backend.name') , array('Attr.EnableID' => true))); ?></th>
                            <th><?php echo e(clean( trans('niva-backend.position') , array('Attr.EnableID' => true))); ?></th>
                        </tr>
                    </thead>
                    <tfoot>
                        <tr>
                            <th><input type="checkbox" id="options1"></th>
                            <th><?php echo e(clean( trans('niva-backend.photo') , array('Attr.EnableID' => true))); ?></th>
                            <th><?php echo e(clean( trans('niva-backend.name') , array('Attr.EnableID' => true))); ?></th>
                            <th><?php echo e(clean( trans('niva-backend.position') , array('Attr.EnableID' => true))); ?></th>
                        </tr>
                    </tfoot>
                    <tbody>
                        <?php if($members): ?>
                            <?php $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><input class="checkboxes" type="checkbox" name="checkbox_array[]" value="<?php echo e($member->id); ?>"></td>
                                    <td><img height="100" src="<?php echo e($member->photo ? '/public/images/media/' . $member->photo->file : '/public/img/200x200.png'); ?>" alt="">
                                    <p class="mb-0 mt-2"><a href="<?php echo e(route('member.edit', $member->id)); ?>"><?php echo e(clean( trans('niva-backend.edit') , array('Attr.EnableID' => true))); ?></a></p>
                                    </td>

                                    <td data-label="link"><?php echo e($member->name); ?></td>
                                    <td data-label="link"><?php echo e($member->position); ?></td>
                                </tr>
                             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>


                        
                    </tbody>
                </table>

                </form>

            </div>
        </div>
    </div>

</div>
<!-- /.container-fluid -->

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/lucilzud/niva.lucian.host/resources/views/member/member-index.blade.php ENDPATH**/ ?>