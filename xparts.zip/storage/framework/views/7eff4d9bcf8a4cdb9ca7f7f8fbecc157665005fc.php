

<?php $__env->startSection('content'); ?>

<!-- Begin Page Content -->
<div class="container-fluid">


    <!-- Page Heading -->
    <h1 class="h3 mb-2 text-gray-800"><?php echo e(clean( trans('niva-backend.section_7_blog') , array('Attr.EnableID' => true))); ?></h1>

    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary"><?php echo e(clean( trans('niva-backend.section_7_blog') , array('Attr.EnableID' => true))); ?></h6>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                
                <div class="row">
                    <div class="col-lg-6">
                        <?php if(Auth::user()->role->name == 'administrator'): ?>
                        <a href="<?php echo e(route('home-setting.edit') . '?language=' . request()->input('language')); ?>" class="btn btn-primary btn-back"><?php echo e(clean( trans('niva-backend.back_homepage') , array('Attr.EnableID' => true))); ?></a>
                        <a href="<?php echo e(route('blog-setting.edit') . '?language=' . request()->input('language')); ?>" class="btn btn-primary btn-back"><?php echo e(clean( trans('niva-backend.back_blogpage') , array('Attr.EnableID' => true))); ?></a>
                        <?php endif; ?>
                        <a href="<?php echo e(route('post.create') . '?language=' . request()->input('language')); ?>" class="btn btn-primary btn-back"><?php echo e(clean( trans('niva-backend.create_article') , array('Attr.EnableID' => true))); ?></a>
                    </div>
                    <div class="col-lg-6 text-right">
                        <?php if(!empty($langs)): ?>
                            <select name="language" class="form-control language-control" onchange="window.location='<?php echo e(url()->current() . '?language='); ?>'+this.value">
                                <option value="" selected disabled><?php echo e(clean( trans('niva-backend.select_language') , array('Attr.EnableID' => true))); ?></option>
                                <?php $__currentLoopData = $langs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($lang->code); ?>" <?php echo e($lang->code == request()->input('language') ? 'selected' : ''); ?>><?php echo e($lang->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        <?php endif; ?>
                    </div>
                </div>

                <?php if($message = Session::get('post_success')): ?>
                    <div class="alert alert-success alert-block">
                        <button type="button" class="close" data-dismiss="alert"><i class="fas fa-times"></i></button>    
                        <strong><?php echo e($message); ?></strong>
                    </div>
                <?php endif; ?>
               

                <form action="<?php echo e(route('delete.post')); ?>" method="POST" class="form-inline">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <div class="form-group">
                    <select name="checkbox_array" id="" class="form-control">
                        <option value=""><?php echo e(clean( trans('niva-backend.delete') , array('Attr.EnableID' => true))); ?></option>
                    </select>
                </div>

                <div class="form-group">
                    <input type="submit" name="delete_all" class="btn btn-primary">
                </div>



                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th><input type="checkbox" id="options"></th>
                            <th scope="col"><?php echo e(clean( trans('niva-backend.id') , array('Attr.EnableID' => true))); ?></th>
                            <th scope="col"><?php echo e(clean( trans('niva-backend.photo') , array('Attr.EnableID' => true))); ?></th>
                            <th scope="col"><?php echo e(clean( trans('niva-backend.owner') , array('Attr.EnableID' => true))); ?></th>
                            <th scope="col"><?php echo e(clean( trans('niva-backend.title') , array('Attr.EnableID' => true))); ?></th>
                            <th scope="col"><?php echo e(clean( trans('niva-backend.category') , array('Attr.EnableID' => true))); ?></th>
                            <th scope="col"><?php echo e(clean( trans('niva-backend.body') , array('Attr.EnableID' => true))); ?></th>
                        </tr>
                    </thead>
                    <tfoot>
                        <tr>
                            <th><input type="checkbox" id="options1"></th>
                            <th scope="col"><?php echo e(clean( trans('niva-backend.id') , array('Attr.EnableID' => true))); ?></th>
                            <th scope="col"><?php echo e(clean( trans('niva-backend.photo') , array('Attr.EnableID' => true))); ?></th>
                            <th scope="col"><?php echo e(clean( trans('niva-backend.owner') , array('Attr.EnableID' => true))); ?></th>
                            <th scope="col"><?php echo e(clean( trans('niva-backend.title') , array('Attr.EnableID' => true))); ?></th>
                            <th scope="col"><?php echo e(clean( trans('niva-backend.category') , array('Attr.EnableID' => true))); ?></th>
                            <th scope="col"><?php echo e(clean( trans('niva-backend.body') , array('Attr.EnableID' => true))); ?></th>
                        </tr>
                    </tfoot>
                    <tbody>
                        <?php if($posts): ?>
                            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><input class="checkboxes" type="checkbox" name="checkbox_array[]" value="<?php echo e($post->id); ?>"></td>
                                    <td data-label="ID"><?php echo e($post->id); ?></td>
                                    <td data-label="Photo"><img height="50" src="<?php echo e($post->photo ? '/public/images/media/' . $post->photo->file : '/public/img/200x200.png'); ?>" alt=""><p class="mb-0 mt-2"><a href="<?php echo e(route('post.edit', $post->id) . '?language=' . request()->input('language')); ?>"><?php echo e(clean( trans('niva-backend.edit') , array('Attr.EnableID' => true))); ?></a></p></td>
                                    <td data-label="OWNER"><?php echo e($post->user->name); ?></td>
                                    <td data-label="TITLE"><?php echo e($post->title); ?></a></td>
                                    <td data-label="Category"><?php echo e($post->category ? $post->category->name : 'Uncategorized'); ?></td>
                                    <td class="body-post" data-label="BODY"><?php echo e($post->meta_description); ?></td>
                                </tr>
                             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>


                        
                    </tbody>
                </table>

                </form>

            </div>
        </div>
    </div>

</div>
<!-- /.container-fluid -->

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/lucilzud/laravel1.lucian.host/resources/views/post/post-index.blade.php ENDPATH**/ ?>