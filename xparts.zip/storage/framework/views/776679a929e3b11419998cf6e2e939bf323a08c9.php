Inquiry from: <?php echo e($name); ?>

<p> Email: <?php echo e($email); ?> </p>
<p> Phone: <?php echo e($phone); ?> </p>
<p> Budget: <?php echo e($budget); ?> </p>
<p> Message: <?php echo e($comment); ?> </p><?php /**PATH /home/lucilzud/laravel1.lucian.host/resources/views/email.blade.php ENDPATH**/ ?>