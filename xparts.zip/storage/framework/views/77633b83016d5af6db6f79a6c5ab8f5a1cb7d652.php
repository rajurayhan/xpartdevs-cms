

<?php $__env->startSection('title'); ?> <?php echo e($page->meta_title); ?> <?php $__env->stopSection(); ?>
<?php $__env->startSection('meta'); ?> <?php echo e($page->meta_description); ?> <?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>
  
  
   <div class="breadcrumb-area">
       <h1 class="breadcrumb-title"><?php echo e($page->meta_title); ?></h1>
   </div>

   <div class="page-content">
   		<div class="container">
   			<?php echo $page->body; ?>

   		</div>
   		
   </div>





<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/lucilzud/niva.lucian.host/resources/views/page.blade.php ENDPATH**/ ?>